#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 14 22:42:15 2020

@author: kuangmeng
"""
import os
import SimpleITK as sitk
import skimage.io as skio
from skimage.transform import resize
import numpy as np

class LoadACDC():
    def __init__(self, data_dir, mode_list):
        self.data_dir = data_dir
        self.mode_list = mode_list
        self.data_set = []
    
    def readSinglePatient(self, patient_path):
        cfg_file = os.path.join(patient_path, 'Info.cfg')
        config = {}
        with open(cfg_file) as f:
            for line in f.readlines():
                config[line.split(':')[0]] = line.split(':')[1].strip()
        file_dict = {}
        patient_name = patient_path.split('/')[-1] if len(patient_path.split('/')[-1]) > 0 else patient_path.split('/')[-2]
        for i in range(len(self.mode_list)):
            if 'GT' in self.mode_list[i]:
                file_dict[self.mode_list[i]] = os.path.join(patient_path, 
                                                           patient_name + 
                                                           '_frame'+ 
                                                           '%02.0d' % (int(config[self.mode_list[i - 1]])) + 
                                                           '_gt.nii.gz')
            else:
                file_dict[self.mode_list[i]] = os.path.join(patient_path, 
                                                           patient_name + 
                                                           '_frame'+ 
                                                           '%02.0d' % (int(config[self.mode_list[i]])) + 
                                                           '.nii.gz')
        return file_dict
    
    def read(self):
        dir_list = os.listdir(self.data_dir)
        for patient_path in dir_list:
            if os.path.isdir(os.path.join(self.data_dir, patient_path)) and 'patient' in patient_path:
                self.data_set.append(self.readSinglePatient(os.path.join(self.data_dir, patient_path)))
        return self.data_set
    
class SaveDataset():
    def __init__(self, data_set, data_type, save_path, new_shape):
        self.data_type = data_type
        self.data_set = data_set
        self.save_path = save_path
        self.save_file = data_type + '.npy'
        self.lens = len(data_set)
        self.new_shape = new_shape
        self.data = []
    
    def make(self):
        for i in range(self.lens):
            self.data.append(self.resizeData(self.readSingleNiiFile(self.data_set[i][self.data_type]), self.new_shape))
    
    def save(self):
        np.save(os.path.join(self.save_path, self.save_file), self.data)
        
    def readSingleNiiFile(self, nii_path):
        img = sitk.ReadImage(nii_path)
        data = sitk.GetArrayFromImage(img)
        return data
    
    def showSingleMRI(self, data, frame):
        skio.imshow(data[frame], cmap = 'gray')
        skio.show()

    def resizeData(self, data, new_shape = (10, 256, 256), order = 3):
        data = resize(data, new_shape, order = order, mode='edge')
        data -= data.mean()
        data /= data.std()
        return data
    
if __name__ == '__main__':
    data_dir = './ACDC'
    processed_dir = './processed_ACDC'
    mode_list = ['ED', 'ED_GT', 'ES', 'ES_GT']
    data_set = LoadACDC(data_dir, mode_list).read()
    for item in mode_list:
        sd = SaveDataset(data_set, item, processed_dir, (10, 256, 256))
        sd.make()
        sd.save()
        print(item)
    
    
    
    
    
    
    
    
    