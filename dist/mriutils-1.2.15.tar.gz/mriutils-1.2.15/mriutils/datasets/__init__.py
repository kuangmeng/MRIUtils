#!/usr/bin/env python

__all__ = ['acdc',
           'brats',
           'lvmvm',
           'mmwhs',
           'mrbrains',
           'pngs']