#!/usr/bin/env python

__all__ = ['test_cube_unet3d_lvmvm']